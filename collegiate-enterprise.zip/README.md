# Collegiate Enterprise

### Team 4E  
**Members:**  
- Jamya Boyd  
- Nikayla Lee  
- Kamika Sneed  
- Xavier O’Neal  

---

## 📘 Project Overview  
Collegiate Enterprise is a university web platform that connects students and professors through an interactive dashboard.  
It allows students to log in, view professors, write reviews, and manage their profiles. Professors can log in to manage courses, view students, and monitor feedback.

---

## 🧠 Features  
- Student & Professor login system  
- Dashboard for each user role  
- Course and review management  
- Profile and review pages  
- Built using **React + TypeScript**

---

## 🧩 Project Structure  
```
src/
 ├── App.tsx
 ├── types.ts
 └── components/
     ├── LoginSelect.tsx
     ├── StudentLogin.tsx
     ├── ProfessorLogin.tsx
     ├── StudentDashboard.tsx
     ├── ProfessorDashboard.tsx
     ├── ProfessorCourses.tsx
     ├── ProfessorStudents.tsx
     ├── HomePage.tsx
     ├── ProfessorList.tsx
     ├── ProfessorDetail.tsx
     ├── WriteReview.tsx
     └── StudentProfile.tsx
```

---

## ⚙️ How to Run
1. Clone the repository  
   ```bash
   git clone https://github.com/yourusername/collegiate-enterprise.git
   cd collegiate-enterprise
   ```
2. Install dependencies  
   ```bash
   npm install
   ```
3. Run the app  
   ```bash
   npm run dev
   ```

---

## 🏫 Alabama A&M University  
Developed by **Team 4E** as part of the **Collegiate Enterprise Project** for the 2025 academic term.
