export type Screen =
  | 'home'
  | 'professor-list'
  | 'professor-detail'
  | 'write-review'
  | 'profile';
