export function ProfessorDashboard() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-semibold">ProfessorDashboard Page</h1>
      <p>This is the ProfessorDashboard component for Collegiate Enterprise.</p>
    </div>
  );
}
