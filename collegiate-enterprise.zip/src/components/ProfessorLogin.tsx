export function ProfessorLogin() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-semibold">ProfessorLogin Page</h1>
      <p>This is the ProfessorLogin component for Collegiate Enterprise.</p>
    </div>
  );
}
