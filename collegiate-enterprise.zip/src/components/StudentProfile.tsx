export function StudentProfile() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-semibold">StudentProfile Page</h1>
      <p>This is the StudentProfile component for Collegiate Enterprise.</p>
    </div>
  );
}
