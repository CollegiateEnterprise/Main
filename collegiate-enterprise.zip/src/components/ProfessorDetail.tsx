export function ProfessorDetail() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-semibold">ProfessorDetail Page</h1>
      <p>This is the ProfessorDetail component for Collegiate Enterprise.</p>
    </div>
  );
}
