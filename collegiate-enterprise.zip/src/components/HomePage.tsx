export function HomePage() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-semibold">HomePage Page</h1>
      <p>This is the HomePage component for Collegiate Enterprise.</p>
    </div>
  );
}
