export function ProfessorList() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-semibold">ProfessorList Page</h1>
      <p>This is the ProfessorList component for Collegiate Enterprise.</p>
    </div>
  );
}
