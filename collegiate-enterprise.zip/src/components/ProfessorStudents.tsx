export function ProfessorStudents() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-semibold">ProfessorStudents Page</h1>
      <p>This is the ProfessorStudents component for Collegiate Enterprise.</p>
    </div>
  );
}
