export function StudentLogin() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-semibold">StudentLogin Page</h1>
      <p>This is the StudentLogin component for Collegiate Enterprise.</p>
    </div>
  );
}
