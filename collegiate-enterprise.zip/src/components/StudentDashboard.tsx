export function StudentDashboard() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-semibold">StudentDashboard Page</h1>
      <p>This is the StudentDashboard component for Collegiate Enterprise.</p>
    </div>
  );
}
