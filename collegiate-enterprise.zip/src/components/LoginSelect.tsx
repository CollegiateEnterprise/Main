export function LoginSelect() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-semibold">LoginSelect Page</h1>
      <p>This is the LoginSelect component for Collegiate Enterprise.</p>
    </div>
  );
}
