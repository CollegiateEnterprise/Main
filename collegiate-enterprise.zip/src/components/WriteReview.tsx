export function WriteReview() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-semibold">WriteReview Page</h1>
      <p>This is the WriteReview component for Collegiate Enterprise.</p>
    </div>
  );
}
